package TestCases;

import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.pages.PageObject;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.util.List;
import Utls.ExcelUtils;


@RunWith(SerenityRunner.class)
public class First extends PageObject {
    @Managed
    WebDriver driver;

    ExcelUtils e;

    @Test
    public void test() throws InterruptedException, IOException {

        open();
        String x=ExcelUtils.read_excel();
        typeInto($("//*[@id=\"ss\"]"),x);


        withAction().click($("//li[@role='option'][1]")).perform();

        List<WebElementFacade> er=findAll("//td//span/span");


        for(int i=1;i<er.size();i++){
            String txt=findAll("//td//span/span").get(i).getText();

            if(txt.equalsIgnoreCase("24"))
            {
                withAction().click(findAll("//td//span/span").get(i)).perform();

            }

            if(txt.equalsIgnoreCase("27")){
                withAction().click(findAll("//td//span/span").get(i)).perform();
                break;
            }

        }

        withAction().click($("//button[@data-sb-id=\"main\"]")).perform();
        Thread.sleep(3000);
        List<WebElementFacade> hlist=findAll("//div[@data-testid=\"title\"]");
        Assert.assertEquals(25,hlist.size());

    }

}
