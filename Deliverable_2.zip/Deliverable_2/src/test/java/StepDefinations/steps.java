package StepDefinations;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import Setup.B_Setup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import Setup.ExcelUtil;
public class steps {
    B_Setup b=new B_Setup();
    ExcelUtil ex=new ExcelUtil();
//    protected WebDriver driver;
 WebDriver driver ;

    @Before
    public void setup() throws IOException {
        driver=b.initializeDriver();
    }

    @Given("Open the booking site")
    public void open_the_booking_site() {
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        try{
            driver.get("https://www.booking.com/");
            driver.manage().window().maximize();
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }


    @When("^I Search for hotel in search Box$")
    public void i_search_for_hotel_in_search_box() throws IOException {
       try{
           String loc= ExcelUtil.read_excel();
           driver.findElement(By.xpath("//*[@id=\"ss\"]")).sendKeys(loc);;
           driver.findElement(By.xpath("//li[@role='option'][1]")).click();
           List<WebElement> l=driver.findElements(By.xpath("//td//span/span"));
//
           for(int j=1;j<l.size();j++){
               String txt=driver.findElements(By.xpath("//td//span/span")).get(j).getText();
               if(txt.equalsIgnoreCase("27"))
               {
                   driver.findElements(By.xpath("//td//span/span")).get(j).click();
               }

               if(txt.equalsIgnoreCase("29")){
                   driver.findElements(By.xpath("//td//span/span")).get(j).click();
                   break;
               }

           }

           driver.findElement(By.xpath("//button[@data-sb-id=\"main\"]")).click();

       }
       catch (Exception e){
           System.err.println(e.getMessage());
       }
    }


    @Then("Show me the result result")
    public void show_me_the_result_result() throws InterruptedException {

       try{
           List<WebElement> hlist=driver.findElements(By.xpath("//div[@data-testid=\"title\"]"));

           Thread.sleep(3000);
//           ArrayList<String> rlist =new ArrayList<String>();
//           for(int i=0;i<=4;i++){
//               rlist.add(i,driver.findElements(By.xpath("//div[@data-testid=\"title\"]")).get(i+1).getText());
//           }
           Assert.assertEquals(hlist.size(), ExcelUtil.Assert_value());
           driver.close();
       }
       catch (Exception e){
           System.err.println(e.getMessage());
       }

    }

    @After
    public void close_setup(){
        driver.quit();
    }
}
